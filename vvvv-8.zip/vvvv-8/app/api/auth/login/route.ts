import { NextRequest, NextResponse } from "next/server"
import { findUserByEmail } from "@/lib/users"
import { signToken, COOKIE_NAME, COOKIE_MAX_AGE } from "@/lib/auth"

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required." }, { status: 400 })
    }

    const user = findUserByEmail(email)
    if (!user || user.password !== password) {
      return NextResponse.json({ error: "Invalid email or password." }, { status: 401 })
    }

    const token = await signToken({ id: user.id, email: user.email, name: user.name })

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, name: user.name, email: user.email },
    })

    response.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: COOKIE_MAX_AGE,
      path: "/",
    })

    return response
  } catch (err) {
    console.error("[/api/auth/login]", err)
    return NextResponse.json({ error: "Internal server error." }, { status: 500 })
  }
}