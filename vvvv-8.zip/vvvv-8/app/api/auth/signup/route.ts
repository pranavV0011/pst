import { NextRequest, NextResponse } from "next/server"
import { findUserByEmail, createUser } from "@/lib/users"
import { hashPassword, signToken, COOKIE_NAME, COOKIE_MAX_AGE } from "@/lib/auth"

export async function POST(req: NextRequest) {
  try {
    const { name, email, password, confirm } = await req.json()

    if (!name || !email || !password || !confirm) {
      return NextResponse.json({ error: "All fields are required." }, { status: 400 })
    }

    if (password !== confirm) {
      return NextResponse.json({ error: "Passwords do not match." }, { status: 400 })
    }

    if (password.length < 8) {
      return NextResponse.json(
        { error: "Password must be at least 8 characters." },
        { status: 400 }
      )
    }

    const existing = findUserByEmail(email)
    if (existing) {
      return NextResponse.json(
        { error: "An account with that email already exists." },
        { status: 409 }
      )
    }

    const passwordHash = await hashPassword(password)
    const user = createUser({ name, email, passwordHash })

    const token = await signToken({ id: user.id, email: user.email, name: user.name })

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, name: user.name, email: user.email },
    })

    response.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: COOKIE_MAX_AGE,
      path: "/",
    })

    return response
  } catch (err) {
    console.error("[/api/auth/signup]", err)
    return NextResponse.json({ error: "Internal server error." }, { status: 500 })
  }
}