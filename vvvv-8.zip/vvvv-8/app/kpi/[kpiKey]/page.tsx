"use client"

import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardContext, type DashboardType } from "@/lib/dashboard-context"
import { useState, use } from "react"
import { KPIDetailView } from "@/components/kpi-detail-view"

export default function KPIDetailPage({ params }: { params: Promise<{ kpiKey: string }> }) {
  const { kpiKey } = use(params)
  const [activeDashboard, setActiveDashboard] = useState<DashboardType>("all-clients")
  const [dateRange, setDateRange] = useState({ from: "Jan 25", to: "Dec 25" })

  return (
    <DashboardContext.Provider value={{ activeDashboard, setActiveDashboard, dateRange, setDateRange }}>
      <div className="flex h-screen overflow-hidden">
        <DashboardSidebar />
        <div className="flex flex-1 flex-col overflow-hidden">
          <DashboardHeader />
          <main className="flex-1 overflow-y-auto bg-background p-6">
            <KPIDetailView kpiKey={kpiKey} />
          </main>
        </div>
      </div>
    </DashboardContext.Provider>
  )
}
