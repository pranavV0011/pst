"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter, useSearchParams } from "next/navigation"
import { cn } from "@/lib/utils"
import { Eye, EyeOff, ArrowRight, Loader2, AlertCircle } from "lucide-react"

// ─── Types ────────────────────────────────────────────────────────────────────

interface FormState {
  name: string
  email: string
  password: string
  confirm: string
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const from = searchParams.get("from") ?? "/dashboard/all-clients"

  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [form, setForm] = useState<FormState>({
    name: "",
    email: "",
    password: "",
    confirm: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null)
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    try {
      const endpoint = isLogin ? "/api/auth/login" : "/api/auth/signup"
      const body = isLogin
        ? { email: form.email, password: form.password }
        : { name: form.name, email: form.email, password: form.password, confirm: form.confirm }

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error ?? "Something went wrong.")
        return
      }

      // Success — redirect to intended destination
      router.push(from)
      router.refresh()
    } catch {
      setError("Network error. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const switchMode = (login: boolean) => {
    setIsLogin(login)
    setError(null)
    setForm({ name: "", email: "", password: "", confirm: "" })
  }

  return (
    <div className="flex h-screen w-full overflow-hidden">
      {/* ── LEFT 60% ── */}
      <div className="relative hidden w-[60%] flex-col items-center justify-center bg-sidebar lg:flex">
        {/* Separator line */}
        <div className="absolute right-0 top-0 h-full w-px bg-sidebar-foreground/10" />

        {/* Ambient glow */}
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 65% 55% at 50% 50%, hsl(var(--sidebar-accent, 215 30% 20%) / 0.4) 0%, transparent 75%)",
          }}
        />

        {/* Corner brackets */}
        <CornerBracket className="left-8 top-8" />
        <CornerBracket className="bottom-8 right-8 rotate-180" />

        {/* Content */}
        <div className="relative z-10 flex flex-col items-center gap-8 px-16 text-center">
          <div className="relative h-24 w-64 drop-shadow-2xl">
            <Image src="/logo-full.png" alt="Jorie AI" fill className="object-contain" priority />
          </div>

          <div className="h-px w-40 rounded-full bg-sidebar-foreground/20" />

          <div className="space-y-3">
            <p
              className="text-2xl font-semibold tracking-tight text-sidebar-foreground"
              style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
            >
              Intelligent Care, Simplified
            </p>
            <p className="max-w-xs text-sm leading-relaxed text-sidebar-foreground/50">
              Your AI-powered healthcare companion — streamlining workflows, elevating outcomes.
            </p>
          </div>

          <div
            className="flex items-center gap-2 rounded-full px-4 py-2 text-xs font-medium text-sidebar-foreground"
            style={{
              background: "hsl(var(--sidebar-accent, 215 30% 20%) / 0.5)",
              border: "1px solid hsl(var(--sidebar-foreground) / 0.12)",
            }}
          >
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            Trusted by 500+ healthcare professionals
          </div>
        </div>
      </div>

      {/* ── RIGHT 40% ── */}
      <div className="flex w-full flex-col items-center justify-center bg-sidebar lg:w-[40%]">
        <div className="w-full max-w-sm px-8">

          {/* Mobile logo */}
          <div className="relative mx-auto mb-8 h-12 w-36 lg:hidden">
            <Image src="/logo-full.png" alt="Jorie AI" fill className="object-contain" priority />
          </div>

          {/* Heading */}
          <div className="mb-8">
            <h1
              className="text-2xl font-bold text-sidebar-foreground"
              style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
            >
              {isLogin ? "Welcome back" : "Create account"}
            </h1>
            <p className="mt-1 text-sm text-sidebar-foreground/50">
              {isLogin
                ? "Sign in to your Jorie AI dashboard"
                : "Get started with Jorie AI today"}
            </p>
          </div>

          {/* Tab toggle */}
          <div
            className="mb-7 flex rounded-lg p-1"
            style={{
              background: "hsl(var(--sidebar-accent, 215 30% 18%) / 0.5)",
              border: "1px solid hsl(var(--sidebar-foreground) / 0.1)",
            }}
          >
            {(["Login", "Sign Up"] as const).map((tab) => {
              const active = (tab === "Login") === isLogin
              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => switchMode(tab === "Login")}
                  className={cn(
                    "flex-1 rounded-md py-2 text-sm font-medium transition-all duration-200",
                    active
                      ? "bg-white/10 text-sidebar-foreground shadow-sm"
                      : "text-sidebar-foreground/40 hover:text-sidebar-foreground/70"
                  )}
                >
                  {tab}
                </button>
              )
            })}
          </div>

          {/* Error banner */}
          {error && (
            <div className="mb-5 flex items-center gap-2.5 rounded-lg border border-red-500/20 bg-red-500/10 px-3.5 py-2.5 text-sm text-red-400">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <Field
                label="Full Name"
                name="name"
                type="text"
                placeholder="Jane Smith"
                value={form.name}
                onChange={handleChange}
              />
            )}

            <Field
              label="Email"
              name="email"
              type="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
            />

            <PasswordField
              label="Password"
              name="password"
              placeholder="••••••••"
              value={form.password}
              onChange={handleChange}
              show={showPassword}
              onToggle={() => setShowPassword((v) => !v)}
            />

            {!isLogin && (
              <PasswordField
                label="Confirm Password"
                name="confirm"
                placeholder="••••••••"
                value={form.confirm}
                onChange={handleChange}
                show={showConfirm}
                onToggle={() => setShowConfirm((v) => !v)}
              />
            )}

            {isLogin && (
              <div className="flex justify-end">
                <button
                  type="button"
                  className="text-xs text-sidebar-foreground/40 transition-opacity hover:text-sidebar-foreground/70"
                >
                  Forgot password?
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="group mt-2 flex w-full items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition-all duration-200 disabled:opacity-60"
              style={{
                background: "hsl(var(--sidebar-foreground))",
                color: "hsl(var(--sidebar))",
              }}
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  {isLogin ? "Sign In" : "Create Account"}
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </>
              )}
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-sidebar-foreground/40">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button
              type="button"
              onClick={() => switchMode(!isLogin)}
              className="underline underline-offset-2 hover:text-sidebar-foreground/70 transition-colors"
            >
              {isLogin ? "Sign up" : "Log in"}
            </button>
          </p>
        </div>
      </div>
    </div>
  )
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function CornerBracket({ className }: { className?: string }) {
  return (
    <svg
      className={cn("absolute opacity-20 text-sidebar-foreground", className)}
      width="80"
      height="80"
      viewBox="0 0 80 80"
      fill="none"
    >
      <path
        d="M0 0 H30 M0 0 V30"
        stroke="currentColor"
        strokeWidth="1.5"
      />
    </svg>
  )
}

function Field({
  label,
  name,
  type,
  placeholder,
  value,
  onChange,
}: {
  label: string
  name: string
  type: string
  placeholder: string
  value: string
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}) {
  return (
    <div className="space-y-1.5">
      <label className="block text-xs font-medium text-sidebar-foreground/60">
        {label}
      </label>
      <input
        required
        name={name}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className={cn(
          "w-full rounded-lg border border-sidebar-foreground/10 bg-white/5 px-3.5 py-2.5",
          "text-sm text-sidebar-foreground placeholder:text-sidebar-foreground/25 outline-none",
          "transition-all focus:border-sidebar-foreground/30 focus:ring-1 focus:ring-sidebar-foreground/20"
        )}
      />
    </div>
  )
}

function PasswordField({
  label,
  name,
  placeholder,
  value,
  onChange,
  show,
  onToggle,
}: {
  label: string
  name: string
  placeholder: string
  value: string
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  show: boolean
  onToggle: () => void
}) {
  return (
    <div className="space-y-1.5">
      <label className="block text-xs font-medium text-sidebar-foreground/60">
        {label}
      </label>
      <div className="relative">
        <input
          required
          name={name}
          type={show ? "text" : "password"}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          className={cn(
            "w-full rounded-lg border border-sidebar-foreground/10 bg-white/5 px-3.5 py-2.5 pr-10",
            "text-sm text-sidebar-foreground placeholder:text-sidebar-foreground/25 outline-none",
            "transition-all focus:border-sidebar-foreground/30 focus:ring-1 focus:ring-sidebar-foreground/20"
          )}
        />
        <button
          type="button"
          onClick={onToggle}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-sidebar-foreground/40 transition-opacity hover:text-sidebar-foreground/70"
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </div>
  )
}