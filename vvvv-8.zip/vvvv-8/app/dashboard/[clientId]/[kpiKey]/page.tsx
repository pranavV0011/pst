"use client"

import { use } from "react"
import { useState } from "react"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { KPIDetailView } from "@/components/kpi-detail-view"
import { DashboardContext, type DashboardType } from "@/lib/dashboard-context"

export default function KpiDetailPage({ params }: { params: Promise<{ clientId: string; kpiKey: string }> }) {
  const { clientId, kpiKey } = use(params)
  const [activeDashboard, setActiveDashboard] = useState<DashboardType>(clientId as DashboardType)
  const [dateRange, setDateRange] = useState({ from: "Jan 25", to: "Dec 25" })

  return (
    <DashboardContext.Provider value={{ activeDashboard, setActiveDashboard, dateRange, setDateRange }}>
      <div className="flex h-screen overflow-hidden">
        <DashboardSidebar />
        <div className="flex flex-1 flex-col overflow-hidden">
          <DashboardHeader />
          <main className="flex-1 overflow-y-auto bg-background p-6">
            <KPIDetailView kpiKey={kpiKey} />
          </main>
        </div>
      </div>
    </DashboardContext.Provider>
  )
}