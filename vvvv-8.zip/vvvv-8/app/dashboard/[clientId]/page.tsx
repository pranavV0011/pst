"use client"

import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { KpiCards } from "@/components/kpi-cards"
import { AutomationKpis } from "@/components/automation-kpis"
import { DashboardContext, type DashboardType } from "@/lib/dashboard-context"
import {
  PerformanceTrendsChart,
  RevenueChart,
  AutomationPenetrationCard,
  ArAgingChart,
  ARDaysTrendChart,
  PeriodComparisonChart,
  DenialReasonsChart,
  ClientPerformanceTable,
} from "@/components/dashboard-charts"
import { useState } from "react"
import { use } from "react"

export default function DashboardPage({ params }: { params: Promise<{ clientId: string }> }) {
  const { clientId } = use(params)
  const [activeDashboard, setActiveDashboard] = useState<DashboardType>(
    clientId as DashboardType
  )

  const [dateRange, setDateRange] = useState({ from: "Jan 25", to: "Dec 25" })

  return (
    <DashboardContext.Provider value={{ activeDashboard, setActiveDashboard, dateRange, setDateRange }}>
      <div className="flex h-screen overflow-hidden">
        <DashboardSidebar />
        <div className="flex flex-1 flex-col overflow-hidden">
          <DashboardHeader />
          <main className="flex-1 overflow-y-auto bg-background p-6">
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-10">
              
              <div className="lg:col-span-7 flex flex-col gap-6">
                <KpiCards />
                <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                  <ArAgingChart />
                  <ARDaysTrendChart />
                  <PeriodComparisonChart />
                </div>
                <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                  <PerformanceTrendsChart />
                  <RevenueChart />
                </div>
                {activeDashboard === "all-clients" && (
                  <div className="grid grid-cols-1 gap-6 lg:grid-cols-1">
                    <ClientPerformanceTable />
                  </div>
                )}
              </div>

              <div className="lg:col-span-3">
                <AutomationKpis />
              </div>
            </div>
          </main>
        </div>
      </div>
    </DashboardContext.Provider>
  )
}