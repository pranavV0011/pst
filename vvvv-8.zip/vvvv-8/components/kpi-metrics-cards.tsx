"use client"

import { Card, CardContent } from "@/components/ui/card"
import { DollarSign, FileText, TrendingUp, TrendingDown, ShieldCheck, Zap } from "lucide-react"
import { cn } from "@/lib/utils"

const metricConfig: Record<string, any> = {
  totalClaims: {
    label: "Total Claims",
    icon: FileText,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%,60%)]/10",
    format: (val: number) => val.toLocaleString(),
  },
  totalPayment: {
    label: "Total Payments",
    icon: DollarSign,
    color: "text-[hsl(168,76%,42%)]",
    bgColor: "bg-[hsl(168,76%,42%)]/10",
    format: (val: number) => `$${(val / 1000000).toFixed(1)}M`,
  },
  totalBilled: {
    label: "Total Billed",
    icon: DollarSign,
    color: "text-[hsl(262,83%,58%)]",
    bgColor: "bg-[hsl(262,83%,58%)]/10",
    format: (val: number) => `$${(val / 1000000).toFixed(1)}M`,
  },
  gcr: {
    label: "GCR",
    icon: TrendingUp,
    color: "text-[hsl(38,92%,50%)]",
    bgColor: "bg-[hsl(38,92%,50%)]/10",
    format: (val: number) => `${val.toFixed(1)}%`,
  },
  denialRate: {
    label: "Denial Rate",
    icon: TrendingDown,
    color: "text-[hsl(0,84%,60%)]",
    bgColor: "bg-[hsl(0,84%,60%)]/10",
    format: (val: number) => `${val.toFixed(1)}%`,
  },
  ccr: {
    label: "CCR",
    icon: ShieldCheck,
    color: "text-[hsl(168,76%,42%)]",
    bgColor: "bg-[hsl(168,76%,42%)]/10",
    format: (val: number) => `${val.toFixed(1)}%`,
  },
  arDays: {
    label: "AR Days",
    icon: Zap,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%,60%)]/10",
    format: (val: number) => `${val.toFixed(1)}`,
  },
  chargePerVisit: {
    label: "Avg. Charge Per Visit",
    icon: DollarSign,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%, 60%)]/10",
    format: (val:number) => `$${val.toFixed(0)}`,
  }
}

export function KPIMetricsCards({
  kpiKey,
  kpis,
  metrics,
}: {
  kpiKey: string
  kpis: any
  metrics: string[]
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
      {metrics.map((metricKey) => {
        const config = metricConfig[metricKey]
        if (!config) return null

        const value = kpis[metricKey] ?? 0
        const Icon = config.icon

        return (
          <Card key={metricKey} className="border-0 shadow-sm h-full">
  <CardContent className="h-full flex items-center p-6">
    <div className="flex items-center gap-4 w-full">
      <div className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-lg", config.bgColor)}>
        <Icon className={cn("h-6 w-6", config.color)} />
      </div>
      <div className="flex flex-col gap-1 min-w-0">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{config.label}</span>
        <span className="text-2xl font-bold text-card-foreground truncate">{config.format(value)}</span>
      </div>
    </div>
  </CardContent>
</Card>
        )
      })}
    </div>
  )
}
