"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Legend,
} from "recharts"
import { useState, useEffect } from "react"
import { loadKPIData } from "@/lib/csv-loader"
import { filterByDateRange, getTotalDaysInRange, getPreviousPeriod, getDaysInMonth } from "@/lib/date-filter"
import { useDashboard } from "@/lib/dashboard-context"

// ===== Color palette =====
const BLUE = "hsl(217, 91%, 60%)"
const GREEN = "hsl(168, 76%, 42%)"
const PURPLE = "hsl(262, 83%, 58%)"
const AMBER = "hsl(38, 92%, 50%)"
const RED = "hsl(0, 84%, 60%)"

// ===== Performance Trends Line Chart =====
export function PerformanceTrendsChart() {
  const [metric, setMetric] = useState("GCR")
  const { dateRange, activeDashboard } = useDashboard()
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

 useEffect(() => {
    const loadData = async () => {
      try {
        const rawData = await loadKPIData(activeDashboard)
        const filteredData = filterByDateRange(rawData, dateRange, "Month&Year")


        
        // Aggregate by Month&Year to avoid duplicates
        const monthMap: Record<string, { GCR: number; DR: number; CCR: number; count: number }> = {}

        filteredData.forEach((row) => {
          const month = row["Month&Year"]
          if (!month) return

          if (!monthMap[month]) {
            monthMap[month] = { GCR: 0, DR: 0, CCR: 0, count: 0 }
          }

          monthMap[month].GCR += Number(row["GCR"]) || 0
          monthMap[month].DR += Number(row["Denial Rate"]) || 0
          monthMap[month].CCR += Number(row["Clean Claim Rate"]) || Number(row["CCR"]) || 0
          monthMap[month].count += 1
        })

        const chartData = Object.entries(monthMap).map(([month, vals]) => ({
          "Month&Year": month,
          GCR: vals.GCR / vals.count,
          DR: vals.DR / vals.count,
          CCR: vals.CCR / vals.count,
        }))

        setData(chartData)
      } catch (error) {
        console.error("Error loading performance data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard])
  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Performance Trends</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">Performance Trends</CardTitle>
        <Tabs value={metric} onValueChange={setMetric}>
          <TabsList className="h-7 gap-0 p-0.5">
            {["GCR", "DR", "CCR"].map((m) => (
              <TabsTrigger key={m} value={m} className="h-6 px-2.5 text-xs">
                {m}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="performanceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={BLUE} stopOpacity={0.15}/>
                  <stop offset="95%" stopColor={BLUE} stopOpacity={0.01}/>
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke="hsl(220, 13%, 91%)" strokeDasharray="3 3" />
              <XAxis dataKey="Month&Year" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} tickFormatter={(v) => `${v}%`} />
              <Tooltip
                contentStyle={{
                  borderRadius: "8px",
                  border: "1px solid hsl(220, 13%, 91%)",
                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                  fontSize: "12px",
                }}
                formatter={(value: number) => [`${value.toFixed(1)}%`, metric]}
              />
              <Area type="monotone" dataKey={metric} stroke={BLUE} strokeWidth={2.5} fill="url(#performanceGradient)" dot={{ r: 3, fill: "white", stroke: BLUE, strokeWidth: 2 }} activeDot={{ r: 5, fill: BLUE, stroke: "white", strokeWidth: 2 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

// ===== Revenue Chart with Real Data =====
export function RevenueChart() {
  const { dateRange, activeDashboard } = useDashboard()
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const rawData = await loadKPIData(activeDashboard)
        const filteredData = filterByDateRange(rawData, dateRange, "Month&Year")

        
const monthMap: Record<string, { Payments: number; Charges: number; count: number }> = {}

filteredData.forEach((row) => {
  const month = row["Month&Year"]
  if (!month) return

  if (!monthMap[month]) monthMap[month] = { Payments: 0, Charges: 0, count: 0 }

  monthMap[month].Payments += Number(row["Payments"]) || 0
  monthMap[month].Charges += Number(row["Charges"]) || 0
  monthMap[month].count += 1
})

const chartData = Object.entries(monthMap).map(([month, vals]) => ({
  "Month&Year": month,
  Payments: vals.Payments / vals.count,
  Charges: vals.Charges / vals.count,
}))


        setData(chartData)
      } catch (error) {
        console.error("Error loading revenue data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard])

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Revenue Overview</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">Revenue Overview</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="gradPayments" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={BLUE} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={BLUE} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradCharges" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={PURPLE} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={PURPLE} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke="hsl(220, 13%, 91%)" strokeDasharray="3 3" />
              <XAxis dataKey="Month&Year" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} tickFormatter={(v) => `$${(v / 1000000).toFixed(0)}M`} />
              <Tooltip
                contentStyle={{
                  borderRadius: "8px",
                  border: "1px solid hsl(220, 13%, 91%)",
                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                  fontSize: "12px",
                }}
                formatter={(value: number) => [`$${(value / 1000000).toFixed(2)}M`]}
              />
              <Area type="monotone" dataKey="Charges" stroke={PURPLE} strokeWidth={2} fill="url(#gradCharges)" dot={{ r: 2 }} />
<Area type="monotone" dataKey="Payments" stroke={BLUE} strokeWidth={2} fill="url(#gradPayments)" dot={{ r: 2 }} />

            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-5 pt-1">
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: BLUE }} />
            Payments
          </div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: PURPLE }} />
            Billed
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
const formatAmount = (value: number) => {
  if (value >= 1_000_000) {
    return `$${(value / 1_000_000).toFixed(1)}M`
  }
  return `$${(value / 1_000).toFixed(0)}K`
}

// ===== AR Bucket Donut Chart with Real Data =====
const PIE_COLORS = [BLUE, PURPLE, AMBER, RED]

export function ArAgingChart() {
  const { dateRange, activeDashboard } = useDashboard()
  const [arData, setArData] = useState<any[]>([])
  const [filterMonth, setFilterMonth] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const rawData = await loadKPIData(activeDashboard)
        const filteredData = filterByDateRange(rawData, dateRange, "Month&Year")

        if (filteredData.length === 0) {
          setArData([])
          setLoading(false)
          return
        }
        
        const lastMonth = filteredData[filteredData.length - 1]["Month&Year"] || ""
        setFilterMonth(lastMonth)

        const lastMonthRows = filteredData.filter(row => row["Month&Year"] == lastMonth)

        const sum030 = lastMonthRows.reduce((sum, row) => sum + (Number(row["0-30"]) || 0), 0)
        const sum3160 = lastMonthRows.reduce((sum, row) => sum + (Number(row["31-60"]) || 0), 0)
        const sum6190 = lastMonthRows.reduce((sum, row) => sum + (Number(row["61-90"]) || 0), 0)
        const sum90plus = lastMonthRows.reduce((sum, row) => sum + (Number(row["90+"]) || 0), 0)


        const total = sum030 + sum3160 + sum6190 + sum90plus || 1

      const chartData = [
  { name: "0-30 days", value: Math.round((sum030 / total) * 100), amount: formatAmount(sum030) },
  { name: "31-60 days", value: Math.round((sum3160 / total) * 100), amount: formatAmount(sum3160) },
  { name: "61-90 days", value: Math.round((sum6190 / total) * 100), amount: formatAmount(sum6190) },
  { name: "90+ days", value: Math.round((sum90plus / total) * 100), amount: formatAmount(sum90plus) },
]

        setArData(chartData)
      } catch (error) {
        console.error("Error loading AR data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard])

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">AR Aging Buckets</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">AR Aging Buckets</CardTitle>
        <span className="text-xs font-medium text-muted-foreground">Through {filterMonth}</span>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center gap-2">
          <div className="h-48 w-48 shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={arData}
                  cx="50%"
                  cy="50%"
                  outerRadius={75}
                  paddingAngle={1}
                  dataKey="value"
                  stroke="none"
                  startAngle={90}
                  endAngle={-270}
                >
                  {arData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    borderRadius: "8px",
                    border: "1px solid hsl(220, 13%, 91%)",
                    boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                    fontSize: "12px",
                  }}
                  formatter={(value, name, props) => {
                    const payload = props.payload as { amount: string }
                    return [`$${payload.amount} (${value}%)`]
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-col gap-4">
            {arData.map((entry, idx) => (
              <div key={entry.name} className="flex items-center gap-2.5">
                <span className="inline-block h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: PIE_COLORS[idx] }} />
                <div className="flex flex-col">
                  <span className="text-xs font-semibold text-card-foreground">{entry.name}</span>
                  <span className="text-xs text-muted-foreground">{entry.amount}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// ===== AR Days Trend Chart with Claims/AR Days Toggle =====
export function ARDaysTrendChart() {
  const { dateRange, activeDashboard } = useDashboard()
  const [activeTab, setActiveTab] = useState<"arDays" | "claims">("arDays")
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const rawData = await loadKPIData(activeDashboard)
        const filteredData = filterByDateRange(rawData, dateRange, "Month&Year")

        const monthMap: Record<
          string,
          { claims: number; arDaysSum: number; count: number }
        > = {}

        filteredData.forEach((row) => {
          const month = row["Month&Year"]
          if (!month) return

          if (!monthMap[month]) {
            monthMap[month] = { claims: 0, arDaysSum: 0, count: 0 }
          }

          monthMap[month].claims += Number(row["Visit"]) || 0
          monthMap[month].arDaysSum += Number(row["AR Days"]) || 0
          monthMap[month].count += 1
        })

        const chartData = Object.entries(monthMap).map(([month, vals]) => ({
          month,
          claims: vals.claims,
          arDays: vals.count > 0 ? vals.arDaysSum / vals.count : 0,
        }))

        setData(chartData)
      } catch (error) {
        console.error("Error loading AR days trend data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard])

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">
            Loading Trend...
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    )
  }

  const dataKey = activeTab === "arDays" ? "arDays" : "claims"

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">
          {activeTab === "arDays" ? "AR Days Trend" : "Claims Trend"}
        </CardTitle>

        <div className="flex items-center rounded-lg border border-border overflow-hidden">
          <button
            onClick={() => setActiveTab("claims")}
            className={`px-3 py-1 text-xs font-medium transition-colors ${
              activeTab === "claims"
                ? "bg-card-foreground text-card"
                : "bg-card text-muted-foreground hover:bg-secondary"
            }`}
          >
            Claims
          </button>

          <button
            onClick={() => setActiveTab("arDays")}
            className={`px-3 py-1 text-xs font-medium transition-colors ${
              activeTab === "arDays"
                ? "bg-card-foreground text-card"
                : "bg-card text-muted-foreground hover:bg-secondary"
            }`}
          >
            AR Days
          </button>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 5, right: 10, left: -10, bottom: 0 }}
            >
              <CartesianGrid
                vertical={false}
                stroke="hsl(220, 13%, 91%)"
                strokeDasharray="3 3"
              />

              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }}
              />

              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }}
                tickFormatter={(value: number) =>
                  activeTab === "arDays"
                    ? `${value.toFixed(0)}d`
                    : value.toLocaleString()
                }
              />

              <Tooltip
                contentStyle={{
                  borderRadius: "8px",
                  border: "1px solid hsl(220, 13%, 91%)",
                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                  fontSize: "12px",
                }}
                formatter={(value: number) => [
                  activeTab === "arDays"
                    ? `${value.toFixed(1)}d`
                    : value.toLocaleString(),
                  activeTab === "arDays"
                    ? "AR Days"
                    : "Claims",
                ]}
              />

              <Bar
                dataKey={dataKey}
                fill={PURPLE}
                barSize={16}
                radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-2 pt-2">
          <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: PURPLE }} />
          <span className="text-xs font-medium text-muted-foreground">
            {activeTab === "arDays" ? "Average Days " : "Claims"}
          </span>
        </div>
      </CardContent>
    </Card>
  )
}


// ===== Period Comparison Chart =====
export function PeriodComparisonChart() {
  const { dateRange, activeDashboard } = useDashboard()
  const [currentData, setCurrentData] = useState<{ gcr: number; ccr: number; dr: number }>({ gcr: 0, ccr: 0, dr: 0 })
  const [previousData, setPreviousData] = useState<{ gcr: number; ccr: number; dr: number }>({ gcr: 0, ccr: 0, dr: 0 })
  const [currentLabel, setCurrentLabel] = useState("")
  
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const rawData = await loadKPIData(activeDashboard)
        const filteredData = filterByDateRange(rawData, dateRange, "Month&Year")

        if (filteredData.length === 0) {
          setLoading(false)
          return
        }

        // Current period: use the last month in filtered data
        // Current period label = full selected range
        setCurrentLabel(
          `${dateRange.from} - ${dateRange.to}`.toUpperCase()
        )


        // Current period averages
        const currGcr = filteredData.reduce((s, r) => s + (Number(r["GCR"]) || 0), 0) / filteredData.length
        const currCcr = filteredData.reduce((s, r) => s + (Number(r["Clean Claim Rate"]) || Number(r["CCR"]) || 0), 0) / filteredData.length
        const currDr = filteredData.reduce((s, r) => s + (Number(r["Denial Rate"]) || 0), 0) / filteredData.length

        setCurrentData({ gcr: currGcr, ccr: currCcr, dr: currDr })

        // Previous period: use getPreviousPeriod to calculate
        const prevPeriod = getPreviousPeriod(dateRange)
        const prevFilteredData = filterByDateRange(rawData, prevPeriod, "Month&Year")

        if (prevFilteredData.length > 0) {
          const prevGcr = prevFilteredData.reduce((s, r) => s + (Number(r["GCR"]) || 0), 0) / prevFilteredData.length
          const prevCcr = prevFilteredData.reduce((s, r) => s + (Number(r["Clean Claim Rate"]) || Number(r["CCR"]) || 0), 0) / prevFilteredData.length
          const prevDr = prevFilteredData.reduce((s, r) => s + (Number(r["Denial Rate"]) || 0), 0) / prevFilteredData.length
          setPreviousData({ gcr: prevGcr, ccr: prevCcr, dr: prevDr })
        }
      } catch (error) {
        console.error("Error loading period comparison data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard])

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Period Comparison</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    )
  }

  const metrics = [
    { label: "GCR", current: currentData.gcr, previous: previousData.gcr },
    { label: "CCR", current: currentData.ccr, previous: previousData.ccr },
    { label: "DR", current: currentData.dr, previous: previousData.dr },
  ]

  // Find max value for scaling bars
  const allValues = metrics.flatMap((m) => [m.current, m.previous])
  const maxVal = Math.max(...allValues, 1)

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">Period Comparison</CardTitle>
        <div className="flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mt-1">
          <span>Prev: Previous Period</span>
          <span>Curr: {currentLabel}</span>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex flex-col gap-6">
          {metrics.map((metric) => (
            <div key={metric.label} className="flex items-center gap-3">
              <span className="w-8 text-xs font-semibold text-card-foreground shrink-0">{metric.label}</span>
              <div className="flex-1 flex flex-col gap-1.5">
                <div className="flex items-center gap-2">
                  <div
                    className="h-3 rounded-sm transition-all"
                    style={{
                      width: `${Math.max((metric.previous / maxVal) * 100, 2)}%`,
                      backgroundColor: PURPLE,
                    }}
                  />
                  <span className="text-[10px] text-muted-foreground shrink-0">{metric.previous.toFixed(1)}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className="h-3 rounded-sm transition-all"
                    style={{
                      width: `${Math.max((metric.current / maxVal) * 100, 2)}%`,
                      backgroundColor: BLUE,
                    }}
                  />
                  <span className="text-[10px] text-muted-foreground shrink-0">{metric.current.toFixed(1)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center gap-5 pt-5">
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: PURPLE }} />
            Previous
          </div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: BLUE }} />
            Current
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// ===== Claims Volume Chart =====
export function ClaimsVolumeChart() {
  const [activeMetric, setActiveMetric] = useState("visits")
  const { dateRange, activeDashboard } = useDashboard()
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const rawData = await loadKPIData(activeDashboard)
        const filteredData = filterByDateRange(rawData, dateRange, "Month&Year")

        const chartData = filteredData.map((row) => ({
          "Month&Year": row["Month&Year"],
          visits: Number(row["Visit"]) || 0,
        }))

        setData(chartData)
      } catch (error) {
        console.error("Error loading claims volume data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard])

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-card-foreground">Claims Volume</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-52 bg-secondary rounded animate-pulse" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-card-foreground">Claims Volume Trend</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="hsl(220, 13%, 91%)" strokeDasharray="3 3" />
              <XAxis dataKey="Month&Year" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "hsl(220, 9%, 46%)" }} />
              <Tooltip
                contentStyle={{
                  borderRadius: "8px",
                  border: "1px solid hsl(220, 13%, 91%)",
                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                  fontSize: "12px",
                }}
              />
              <Bar dataKey="visits" fill={BLUE} barSize={8} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

// ===== Placeholder Components =====
export function DenialReasonsChart() {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle className="text-sm font-semibold text-card-foreground">Denial Reasons</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-center h-52">
        <p className="text-sm text-muted-foreground">Denial breakdown data</p>
      </CardContent>
    </Card>
  )
}

export function ClientPerformanceTable() {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle className="text-sm font-semibold text-card-foreground">Client Performance</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-center h-52">
        <p className="text-sm text-muted-foreground">Performance metrics table</p>
      </CardContent>
    </Card>
  )
}

export function AutomationPenetrationCard() {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle className="text-sm font-semibold text-card-foreground">Automation Penetration</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-center h-52">
        <p className="text-sm text-muted-foreground">Automation metrics</p>
      </CardContent>
    </Card>
  )
}
