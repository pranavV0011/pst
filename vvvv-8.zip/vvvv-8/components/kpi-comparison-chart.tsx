"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  LabelList,
} from "recharts"

const metricConfig: Record<string, any> = {
  totalClaims: { label: "Total Claims", format: (v: number) => v.toLocaleString(), max: 10000 },
  totalPayment: { label: "Total Payments", format: (v: number) => `$${(v / 1000000).toFixed(1)}M`, max: 100 },
  totalBilled: { label: "Total Billed", format: (v: number) => `$${(v / 1000000).toFixed(1)}M`, max: 100 },
  gcr: { label: "GCR (%)", format: (v: number) => `${v.toFixed(1)}%`, max: 100 },
  denialRate: { label: "Denial Rate (%)", format: (v: number) => `${v.toFixed(1)}%`, max: 100 },
  ccr: { label: "CCR (%)", format: (v: number) => `${v.toFixed(1)}%`, max: 100 },
  arDays: { label: "AR Days", format: (v: number) => `${v.toFixed(1)}`, max: 100 },
  chargePerVisit: {label: "Charge Per Visit", format: (v: number) => `$${v.toFixed(1)}`, max:100}
}


// Custom tooltip
function CustomTooltip({ active, payload, formatter }: any) {
  if (active && payload && payload.length) {
    const { name, value } = payload[0]
    return (
      <div className="rounded-lg border border-border bg-card px-4 py-2 shadow-md text-sm">
        <p className="font-semibold text-card-foreground">{name}</p>
        <p className="text-muted-foreground">{formatter ? formatter(value) : value}</p>
      </div>
    )
  }
  return null
}

// Custom top label
function TopLabel({ x, y, width, value, formatter }: any) {
  return (
    <text
      x={x + width / 2}
      y={y - 10}
      fill="hsl(var(--foreground))"
      textAnchor="middle"
      fontSize={13}
      fontWeight={600}
    >
      {formatter ? formatter(value) : value}
    </text>
  )
}

export function KPIComparisonChart({
  kpiKey,
  kpis,
  metrics,
  monthlyTrend,
}: {
  kpiKey: string
  kpis: any
  metrics: string[]
  monthlyTrend: any[]
}) {
  const primaryMetric = metrics[0]
  const primaryConfig = metricConfig[primaryMetric]

  const currentMonthValue =
    monthlyTrend.length > 0 ? monthlyTrend[monthlyTrend.length - 1].value : 0

  const last3 = monthlyTrend.slice(-4, -1)
  const last3AvgValue =
    last3.length > 0
      ? last3.reduce((sum: number, m: any) => sum + m.value, 0) / last3.length
      : 0

  if (!primaryMetric) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Comparative Analysis</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">
            No comparison data available
          </div>
        </CardContent>
      </Card>
    )
  }

  const chartData = [
    {
      name: "Current Month",
      value: currentMonthValue,
      color: "hsl(262, 83%, 58%)",
    },
    {
      name: "Last 3 Mo. Avg",
      value: last3AvgValue,
      color: "hsl(262, 83%, 58%)",
    },
  ]

  const allValues = chartData.map((d) => d.value)
  const yMax = Math.max(...allValues) * 1.25 // 25% headroom so labels never clip

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold">Comparative Analysis</CardTitle>
        <p className="text-xs text-muted-foreground mt-1">
          {primaryConfig?.label} — Current Month vs Last 3 Months Average
        </p>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <ResponsiveContainer width="100%" height={260}>
          <BarChart
            data={chartData}
            margin={{ top: 32, right: 40, left: 40, bottom: 8 }}
            barCategoryGap="40%"
          >
            <CartesianGrid
              strokeDasharray="4 4"
              vertical={false}
              stroke="hsl(var(--border))"
            />
            <XAxis
              dataKey="name"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))", fontWeight: 500 }}
            />
            <YAxis hide domain={[0, yMax]} />
            <Tooltip
              cursor={{ fill: "hsl(var(--muted))", radius: 6 }}
              content={<CustomTooltip formatter={primaryConfig?.format} />}
            />
            <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={100}>
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
              <LabelList
                dataKey="value"
                content={(props) => (
                  <TopLabel {...props} formatter={primaryConfig?.format} />
                )}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}