"use client"

import { useEffect, useState } from "react"
import { useDashboard } from "@/lib/dashboard-context"
import { loadKPIData } from "@/lib/csv-loader"
import { filterDataByDateRange, calculateKPIs, getMonthlyTrend, getChargePerVisitTrend } from "@/lib/data-aggregation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { KPIMetricsCards } from "./kpi-metrics-cards"
import { KPITrendChart } from "./kpi-trend-chart"
import { KPIComparisonChart } from "./kpi-comparison-chart"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"

const kpiConfig: Record<string, any> = {
  totalClaims: {
    label: "Total Claims",
    description: "Total number of claims processed",
    metrics: ["totalClaims", "totalBilled", "totalPayment"],
    trendField: "Visit",
  },
  totalPayment: {
    label: "Total Payments",
    description: "Total payments received",
    metrics: ["totalPayment", "totalBilled", "totalClaims"],
    trendField: "Payments",
  },
  totalBilled: {
    label: "Total Billed",
    description: "Total billing amount",
    metrics: ["totalBilled", "totalPayment", "totalClaims"],
    trendField: "Charges",
  },
  gcr: {
    label: "GCR (Gross Charge Rate)",
    description: "Gross charge rate performance",
    metrics: ["gcr", "totalPayment", "totalBilled"],
    trendField: "GCR",
  },
  ccr: {
    label: "CCR (Clean Claim Rate)",
    description: "Clean claim rate performance",
    metrics: ["ccr", "gcr", "denialRate"],
    trendField: "Clean Claim Rate",
  },
  denialRate: {
    label: "Denial Rate",
    description: "Claims denial rate",
    metrics: ["denialRate", "ccr", "gcr"],
    trendField: "Denial Rate",
  },
  arDays: {
    label: "AR Days",
    description: "Average days in accounts receivable",
    metrics: ["arDays", "totalPayment", "totalClaims"],
    trendField: "AR Days",
  },
  chargePerVisit: {
    label: "Avg. Charge Per Visit",
    description: "Charges billed per visit",
    metrics: ["chargePerVisit", "totalBilled", "totalClaims"],
    trendField: "Charge Per Visit"
  }
}

export function KPIDetailView({ kpiKey }: { kpiKey: string }) {
  const { dateRange, activeDashboard } = useDashboard()
  const [loading, setLoading] = useState(true)
  const [kpis, setKpis] = useState<any>(null)
  const [monthlyTrend, setMonthlyTrend] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)
  const params = useParams()
  const clientId = params.clientId as string

  const config = kpiConfig[kpiKey] || {
    label: "Unknown KPI",
    description: "No description available",
    metrics: [],
    trendField: "",
  }

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true)
        const data = await loadKPIData(activeDashboard)
        const filteredData = filterDataByDateRange(data, dateRange.from, dateRange.to)

        if (!filteredData.length) {
          setError("No data available for the selected period")
          setLoading(false)
          return
        }

        const kpiData = await calculateKPIs(filteredData)
        setKpis(kpiData)

        // Get monthly trend data
        if (kpiKey == "chargePerVisit"){
          const trend = getChargePerVisitTrend(filteredData)
          setMonthlyTrend(trend)
        } else if (config.trendField){
          const trend = getMonthlyTrend(filteredData, config.trendField, "sum")
          setMonthlyTrend(trend)
        }

        setError(null)
      } catch (err) {
        console.error("[v0] Error loading KPI detail data:", err)
        setError("Failed to load KPI data")
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard, kpiKey, config])

  if (loading) {
    return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Link href={`/dashboard/${clientId}`}>
            <Button variant="ghost" size="sm" className=" hover:bg-sidebar-accent hover:text-sidebar-foreground">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-card-foreground">{config.label}</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-1 ml-9">{config.description}</p>
      </div>

      {/* Metrics Cards */}
      {kpis && <KPIMetricsCards kpiKey={kpiKey} kpis={kpis} metrics={config.metrics} />}

      {/* Charts */}
      <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
        <KPITrendChart kpiKey={kpiKey} monthlyTrend={monthlyTrend} config={config} />
        <KPIComparisonChart kpiKey={kpiKey} kpis={kpis} metrics={config.metrics} monthlyTrend={monthlyTrend}/>
      </div>
    </div>
  )
}

  if (error || !kpis) {
    return (
      <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Link href={`/dashboard/${clientId}`}>
            <Button variant="ghost" size="sm" className=" hover:bg-sidebar-accent hover:text-sidebar-foreground">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-card-foreground">{config.label}</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-1 ml-9">{config.description}</p>
      </div>

      {/* Metrics Cards */}
      {kpis && <KPIMetricsCards kpiKey={kpiKey} kpis={kpis} metrics={config.metrics} />}

      {/* Charts */}
      <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
        <KPITrendChart kpiKey={kpiKey} monthlyTrend={monthlyTrend} config={config} />
        <KPIComparisonChart kpiKey={kpiKey} kpis={kpis} metrics={config.metrics} monthlyTrend={monthlyTrend}/>
      </div>
    </div>
  )
}

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Link href={`/dashboard/${clientId}`}>
            <Button variant="ghost" size="sm" className=" hover:bg-sidebar-accent hover:text-sidebar-foreground">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-card-foreground">{config.label}</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-1 ml-9">{config.description}</p>
      </div>

      {/* Metrics Cards */}
      {kpis && <KPIMetricsCards kpiKey={kpiKey} kpis={kpis} metrics={config.metrics} />}

      {/* Charts */}
      <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
        <KPITrendChart kpiKey={kpiKey} monthlyTrend={monthlyTrend} config={config} />
        <KPIComparisonChart kpiKey={kpiKey} kpis={kpis} metrics={config.metrics} monthlyTrend={monthlyTrend}/>
      </div>
    </div>
  )
}