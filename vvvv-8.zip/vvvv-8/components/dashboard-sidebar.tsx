"use client"

import { cn } from "@/lib/utils"
import { usePathname } from "next/navigation"  // ← add this import
import Image from "next/image"
import {
  LayoutDashboard,
  Users,
  Settings,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"

const dashboards = [
  { icon: LayoutDashboard, label: "All Client Dashboard", id: "all-clients" },
  { icon: Users, label: "Wagner Kapoor", id: "abc" },
  { icon: Users, label: "Entfw", id: "dce" },
  { icon: Users, label: "Pomerene", id: "pom" },
  { icon: Users, label: "Southside", id:"southside"}
]

const bottomItems = [
  { icon: Settings, label: "Settings" },
  { icon: HelpCircle, label: "Help" },
]

export function DashboardSidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const pathname = usePathname()   // ← add this
  const router = useRouter()
  // ← remove useDashboard entirely

  return (
    <aside className={cn(
      "flex h-screen flex-col bg-sidebar text-sidebar-foreground transition-all duration-300",
      collapsed ? "w-16" : "w-56"
    )}>
      {/* Logo */}
      <div className="flex h-20 items-center justify-center px- pt-6">
        <div className={cn("relative transition-all duration-300", collapsed ? "h-10 w-10" : "h-24 w-full")}>
          {!collapsed? (
          <Image src="/logo-full.png" alt="Jorie Ai" fill className="object-contain" priority/>
          ):(
            <Image src="/logo-icon.png" alt="Company Icon" fill className="object-contain" priority/>
          )}
        </div>
      </div>

      {/* Dashboards */}
      <nav className="flex flex-1 flex-col gap-1 px-2 pt-4">
        {dashboards.map((dashboard) => (
          <button
            key={dashboard.id}
            onClick={() => router.push(`/dashboard/${dashboard.id}`)}  // ← simplified
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              pathname.includes(dashboard.id)   // ← replaced activeDashboard === dashboard.id
                ? "bg-sidebar-accent text-sidebar-primary"
                : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground"
            )}
          >
            <dashboard.icon className="h-4 w-4 shrink-0" />
            {!collapsed && <span>{dashboard.label}</span>}
          </button>
        ))}
      </nav>

      {/* Bottom items */}
      <div className="flex flex-col gap-1 border-t border-sidebar-border px-2 py-3">
        {bottomItems.map((item) => (
          <button
            key={item.label}
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
          >
            <item.icon className="h-4 w-4 shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </button>
        ))}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/40 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4 shrink-0" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4 shrink-0" />
              <span>Collapse</span>
            </>
          )}
        </button>
      </div>
    </aside>
  )
}