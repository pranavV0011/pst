"use client"

import { Card } from "@/components/ui/card"
import { useState, useEffect } from "react"
import { useDashboard } from "@/lib/dashboard-context"
import { loadAutomationData } from "@/lib/csv-loader"
import { filterDataByMonth, parseMonthYear } from "@/lib/data-aggregation"

interface AutomationKPI {
  label: string
  percentage: number
  value: number
  totalValue: number
}

export function AutomationKpis() {
  const { activeDashboard, dateRange } = useDashboard()
  const [kpis, setKpis] = useState<AutomationKPI[]>([])
  const [overallPercentage, setOverallPercentage] = useState(0)
  const [loading, setLoading] = useState(true)
  const [animatedPercentage, setAnimatedPercentage] = useState(0)

  useEffect(() => {
    const loadAutomation = async () => {
      try {
        let data: any[] = []

        if (activeDashboard === "all-clients") {
          // Load data for ALL clients
          const clientDashboards = ["abc", "dce", "pom"] // replace with your real client keys

          const allData = await Promise.all(
            clientDashboards.map(client => loadAutomationData(client))
          )

          // Flatten into single dataset
          data = allData.flat()
        } else {
          data = await loadAutomationData(activeDashboard)
        }

        if (data.length === 0) {
          setKpis([])
          setLoading(false)
          return
        }


        // Filter by the "to" month (show only for the filter month)
        const filteredData = filterDataByMonth(data, dateRange.to)

        if (filteredData.length === 0) {
          setKpis([])
          setLoading(false)
          return
        }

        // Detect bot<x> / totalvol<x> column pairs dynamically
        const headers = Array.from(
          new Set(
            filteredData.flatMap(row => Object.keys(row))
          )
        )
        const botColumns = headers.filter(h => h.startsWith('bot'))
        const kpiPairs: { label: string; botKey: string; totalKey: string }[] = []

        const kpiLabels: Record<string, string> = {
          pa: 'Prior Authorization',
          charge: 'Charge Entry',
          pp: 'Payment Posting',
          ev: 'Eligibility Verification',
          ar: 'Account Receivable',
          cs: 'Claim Submission',
          dm: 'Denial Management',
          cr: 'Coding Review',
          era: 'ERA Processing',
          rm: 'Referral Management',
          id: 'Insurance Discovery',
          ap: 'Appeal Processing',
          cred: 'Credentialing',
          bar: 'Billing Accuracy Report',
          ft: 'FastTrack Appointments',
          ef: 'Encounters form',
          eaa: 'SDEC Eligibility and Auth',

          hs: 'WKI HubSpot',
          ics: 'WKI Injection charge scrub',
          mcs: 'WKI Medical Charge Scrub',
          np: 'WKI Non Par',
          nsa: 'WKI No Show Appointment',
          dc: 'Drug Count',
          sef: 'SDEC Encounters Form'

        }

        botColumns.forEach((botCol) => {
          const suffix = botCol.replace('bot', '')
          const totalCol = `totalvol${suffix}`
          if (headers.includes(totalCol)) {
            kpiPairs.push({
              label: kpiLabels[suffix] || suffix.toUpperCase(),
              botKey: botCol,
              totalKey: totalCol,
            })
          }
        })

        // Aggregate across all filtered rows (sum bot / sum totalvol * 100)
        const automationKpis: AutomationKPI[] = []
        let totalPercentage = 0

        kpiPairs.forEach(({ label, botKey, totalKey }) => {
          const botSum = filteredData.reduce((sum, row) => sum + (Number(row[botKey]) || 0), 0)
          const totalSum = filteredData.reduce((sum, row) => sum + (Number(row[totalKey]) || 0), 0)
          const percentage = totalSum > 0 ? (botSum / totalSum) * 100 : 0

          automationKpis.push({
            label,
            percentage: Math.round(percentage * 10) / 10,
            value: botSum,
            totalValue: totalSum,
          })
          totalPercentage += percentage
        })

        // Calculate overall average
        const overallAvg = automationKpis.length > 0 ? totalPercentage / automationKpis.length : 0

        setKpis(automationKpis)
        setOverallPercentage(Math.round(overallAvg))
      } catch (error) {
        console.error("[v0] Failed to load automation data:", error)
        setKpis([])
      } finally {
        setLoading(false)
      }
    }

    loadAutomation()
  }, [activeDashboard, dateRange])

  useEffect(() => {
  if (overallPercentage === 0) return
  setAnimatedPercentage(0)
  const duration = 1500 // ms
  const startTime = performance.now()

  const animate = (currentTime: number) => {
    const elapsed = currentTime - startTime

    const progress = Math.min(elapsed / duration, 1)
    // Ease out cubic
    const eased = 1 - Math.pow(1 - progress, 3)
    setAnimatedPercentage(Math.round(eased * overallPercentage))
    if (progress < 1) requestAnimationFrame(animate)
  }

  requestAnimationFrame(animate)
  }, [overallPercentage])

  const getGaugeColor = (percentage: number) => {
    const section = 100/3

    if (percentage <= section)
      return {gauge: "#ef4444", status: "Low Efficiency"}

    if (percentage <= section * 2)
      return {gauge: "#f59e0b", status: "Medium Efficiency"}

    return {gauge: "#10b981", status: "High Efficiency"}
  }

  const gaugeStyle = getGaugeColor(animatedPercentage)
  const gaugePercentage = Math.min(Math.max(animatedPercentage, 0), 100)

  // 0% = 180° (left)
  // 50% = 90° (top)
  // 100% = 0° (right)
  const needleAngle = 180 - (gaugePercentage / 100) * 180
  const needleRadians = (needleAngle * Math.PI) / 180

  const centerX = 120
  const centerY = 100
  const radius = 60

  const needlex = centerX + radius * Math.cos(needleRadians)
  const needleY = centerY - radius * Math.sin(needleRadians) // IMPORTANT: minus sign

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <div className="p-6 h-96 bg-secondary rounded animate-pulse" />
      </Card>
    )
  }

  const avgScore = kpis.length > 0 ? Math.round((kpis.reduce((sum, k) => sum + k.percentage, 0) / kpis.length)) : 0

  return (
    <Card className="border-0 shadow-sm flex flex-col h-full">
      {/* Overall Automation Performance */}
      <div className="p-2 border-b border-border">
        <h3 className="text-center text-sm font-semibold text-card-foreground mb-6">Overall Automation Performance</h3>

        {/* Gauge Chart */}
        <div className="flex justify-center mb-4">
          <svg viewBox="0 0 240 130" className="w-full h-auto" style={{ maxWidth: "270px" }}>
            {/* 
              Semicircle from 180° (left) to 0° (right), center=(120,110), r=80
              Angles in standard math coords, SVG y is flipped.

              Key points:
                180° → (40, 110)   — leftmost
                120° → (80, 41.3)  — 33% mark
                 60° → (160, 41.3) — 66% mark
                  0° → (200, 110)  — rightmost

              Arc formula: x = cx + r*cos(θ), y = cy - r*sin(θ)
            -->

            {/* Background track */}
            <path
              d="M 40 110 A 80 80 0 0 1 200 110"
              fill="none"
              stroke="#e5e7eb"
              strokeWidth="14"
              strokeLinecap="butt"
            />

            {/* Red segment: 180° → 120° (0–33%) */}
            <path
              d="M 40 110 A 80 80 0 0 1 80 41.3"
              fill="none"
              stroke="#ef4444"
              strokeWidth="14"
              strokeLinecap="butt"
            />

            {/* Orange segment: 120° → 60° (33–66%) */}
            <path
              d="M 80 41.3 A 80 80 0 0 1 160 41.3"
              fill="none"
              stroke="#f59e0b"
              strokeWidth="14"
              strokeLinecap="butt"
            />

            {/* Green segment: 60° → 0° (66–100%) */}
            <path
              d="M 160 41.3 A 80 80 0 0 1 200 110"
              fill="none"
              stroke="#10b981"
              strokeWidth="14"
              strokeLinecap="butt"
            />

            {/* Needle */}
            <line
              x1="120"
              y1="110"
              x2={120 + 70 * Math.cos(Math.PI - (gaugePercentage / 100) * Math.PI)}
              y2={110 - 70 * Math.sin(Math.PI - (gaugePercentage / 100) * Math.PI)}
              stroke={gaugeStyle.gauge}
              strokeWidth="2.5"
              strokeLinecap="round"
            />

            {/* Center dot */}
            <circle cx="120" cy="110" r="5" fill={gaugeStyle.gauge} />

            {/* Labels */}
            <text x="38" y="126" fontSize="10" fill="#6b7280" textAnchor="middle" fontWeight="500">0%</text>
            <text x="120" y="126" fontSize="10" fill="#6b7280" textAnchor="middle" fontWeight="500">50%</text>
            <text x="202" y="126" fontSize="10" fill="#6b7280" textAnchor="middle" fontWeight="500">100%</text>
          </svg>
        </div>

        {/* Percentage Display */}
        <div className="flex items-center justify-center gap-8 mt-2">
          {/* Left Side - Percentage */}
          <div className="text-center">
            <p className="text-2xl font-bold text-card-foreground">
              {overallPercentage}%
            </p>

            <p
              className="text-xs font-medium"
              style={{ color: gaugeStyle.gauge }}
            >
              {gaugeStyle.status}
            </p>
          </div>

          {/* Divider */}
          <div className="w-px h-12 bg-border" />

          {/* Right Side - KPI Summary */}
          <div className="text-center">
            <p className="text-lg font-semibold text-card-foreground">
              {kpis.length}
            </p>
            <p className="text-[12px] text-muted-foreground">Total KPIs</p>
          </div>
        </div>

      </div>

      {/* Key Automation KPIs */}
      <div className="flex-1 p-4 overflow-y-auto">
        <h3 className="text-xs font-semibold text-muted-foreground mb-3">Automation Penetration</h3>
        <div className="flex flex-col gap-4">
          {kpis.map((kpi, idx) => (
            <div key={idx} className="flex items-start gap-3">
              {/* Progress bar on left */}
              <div className="flex-1 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-card-foreground line-clamp-1">{kpi.label}</label>
                  <span className="text-xs font-bold text-card-foreground ml-2 shrink-0">{Math.round(kpi.percentage)}%</span>
                </div>
                <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(kpi.percentage, 100)}%`,
                      backgroundColor: kpi.percentage >= 80 ? "#10b981" : kpi.percentage >= 50 ? "#f59e0b" : "#ef4444",
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {kpis.length === 0 && (
          <div className="flex items-center justify-center h-24 text-sm text-muted-foreground">
            No automation data available
          </div>
        )}
      </div>

      {/* Summary Footer */}

    </Card>
  )
}
