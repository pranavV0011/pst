"use client"

import { Card } from "@/components/ui/card"
import {
  DollarSign,
  FileText,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Calendar,
  Zap,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"
import { loadKPIData } from "@/lib/csv-loader"
import { filterDataByDateRange, calculateKPIs } from "@/lib/data-aggregation"
import { useDashboard } from "@/lib/dashboard-context"
import Link from "next/link"
import { useParams } from "next/navigation";

const NON_DRILLABLE_KPIS = ["arDays", "ccr"]

const kpiConfig = [
  {
    label: "Total Claims",
    key: "totalClaims",
    icon: FileText,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%,60%)]/10",
    format: (val: number) => val.toLocaleString(),
  },
  {
    label: "Total Payments",
    key: "totalPayment",
    icon: DollarSign,
    color: "text-[hsl(168,76%,42%)]",
    bgColor: "bg-[hsl(168,76%,42%)]/10",
    format: (val: number) => `$${(val / 1000000).toFixed(1)}M`,
  },
  {
    label: "Total Billed",
    key: "totalBilled",
    icon: DollarSign,
    color: "text-[hsl(262,83%,58%)]",
    bgColor: "bg-[hsl(262,83%,58%)]/10",
    format: (val: number) => `$${(val / 1000000).toFixed(1)}M`,
  },
  {
    label: "GCR",
    key: "gcr",
    icon: TrendingUp,
    color: "text-[hsl(38,92%,50%)]",
    bgColor: "bg-[hsl(38,92%,50%)]/10",
    format: (val: number) => `${val.toFixed(1)}%`,
  },
  {
    label: "Denial Rate",
    key: "denialRate",
    icon: TrendingDown,
    color: "text-[hsl(0,84%,60%)]",
    bgColor: "bg-[hsl(0,84%,60%)]/10",
    format: (val: number) => `${val.toFixed(1)}%`,
  },
   {
    label: "Avg. Charge Per Visit",
    key: "chargePerVisit",
    icon: DollarSign,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%, 60%)]/10",
    format: (val:number) => `$${val.toFixed(0)}`,
  },
  {
    label: "CCR",
    key: "ccr",
    icon: ShieldCheck,
    color: "text-[hsl(168,76%,42%)]",
    bgColor: "bg-[hsl(168,76%,42%)]/10",
    format: (val: number) => `${val.toFixed(1)}%`,
  },
  {
    label: "AR Days",
    key: "arDays",
    icon: Zap,
    color: "text-[hsl(217,91%,60%)]",
    bgColor: "bg-[hsl(217,91%,60%)]/10",
    format: (val: number) => `${val.toFixed(1)}`,
  },
]

export function KpiCards() {
  const { dateRange, activeDashboard } = useDashboard()
  const params = useParams()
  const clientId = params.clientId as string
  const [kpis, setKpis] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const data = await loadKPIData(activeDashboard)
        const filteredData = filterDataByDateRange(data, dateRange.from, dateRange.to)

        if (!filteredData.length) {
          setKpis(getDefaultKPIs())
          setLoading(false)
          return
        }

        const kpiData = await calculateKPIs(filteredData)

        const computedValues: Record<string, number> = {
          totalClaims: kpiData.totalClaims,
          totalPayment: kpiData.totalPayment,
          totalBilled: kpiData.totalBilled,
          gcr: kpiData.gcr,
          denialRate: kpiData.denialRate,
          ccr: kpiData.ccr,
          arDays: kpiData.arDays,
          dailyAvgCharges: kpiData.dailyAvgCharges,
          chargePerVisit: kpiData.chargePerVisit
        }

        const kpiValues = kpiConfig.map((config) => {
          const value = computedValues[config.key] ?? 0

          return {
            ...config,
            value: config.format(value),
            change: "—",
            trend: "up",
          }
        })

        setKpis(kpiValues)
      } catch (error) {
        console.error("[v0] Error loading KPI data:", error)
        setKpis(getDefaultKPIs())
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [dateRange, activeDashboard])

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {[...Array(8)].map((_, i) => (
          <Card key={i} className="border-0 p-4 shadow-sm animate-pulse">
            <div className="h-10 w-10 rounded-lg bg-secondary mb-2" />
            <div className="h-4 bg-secondary rounded mb-1" />
            <div className="h-5 bg-secondary rounded w-3/4" />
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
      {kpis.map((kpi) => {
        const isDrillable = !NON_DRILLABLE_KPIS.includes(kpi.key)

        const card = (
          <Card className = {cn(
            "flex items-center gap-4 border-0 p-4 shadow-sm transition-all",
            isDrillable && "cursor-pointer hover:shadow-md hover:scale-105 active:scale-100"
          )}>
            <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg", kpi.bgColor)}>
              <kpi.icon className={cn("h-5 w-5", kpi.color)} />
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-xs font-medium text-muted-foreground">{kpi.label}</span>
              <div className="flex items-baseline gap-2">
                <span className="text-lg font-bold text-card-foreground">{kpi.value}</span>
              </div>
            </div>
          </Card>
        )

        return isDrillable ? (
          <Link key={kpi.label} href={`/dashboard/${clientId}/${kpi.key}`}>
            {card}
          </Link>
        ) : (
          <div key={kpi.label}>{card}</div>
        )
      })}
    </div>
  )
}

function getDefaultKPIs() {
  return kpiConfig.map((config) => ({
    ...config,
    value: "—",
    change: "—",
    trend: "up",
  }))
}
