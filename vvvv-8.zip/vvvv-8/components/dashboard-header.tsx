"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Bell, ChevronDown, Sun, Moon } from "lucide-react"
import { useState, useRef, useEffect } from "react"
import { useDashboard } from "@/lib/dashboard-context"

// Generate all months from January 2024 to current month
function generateMonthsList() {
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  const months: string[] = []

  const startYear = 2024
  const now = new Date()
  const currentYear = now.getFullYear()
  const currentMonth = now.getMonth() + 1

  for (let year = startYear; year <= currentYear; year++) {
    const endMonth = year === currentYear ? currentMonth : 12
    for (let month = 1; month <= endMonth; month++) {
      const monthName = monthNames[month - 1]
      const yearShort = String(year).slice(-2)
      months.push(`${monthName} ${yearShort}`)
    }
  }

  return months
}

const months = generateMonthsList()

export function DashboardHeader() {
  const { dateRange, setDateRange } = useDashboard()
  const [fromOpen, setFromOpen] = useState(false)
  const [toOpen, setToOpen] = useState(false)
  const [isDark, setIsDark] = useState(true)
  const fromRef = useRef<HTMLDivElement>(null)
  const toRef = useRef<HTMLDivElement>(null)

  // Initialize theme from <html> class on mount
  useEffect(() => {
    const html = document.documentElement
    setIsDark(html.classList.contains("dark"))
  }, [])

  function toggleTheme() {
    const html = document.documentElement
    if (isDark) {
      html.classList.remove("dark")
      setIsDark(false)
    } else {
      html.classList.add("dark")
      setIsDark(true)
    }
  }

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (fromRef.current && !fromRef.current.contains(event.target as Node)) {
        setFromOpen(false)
      }
      if (toRef.current && !toRef.current.contains(event.target as Node)) {
        setToOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-card px-6">
      <div className="flex items-center gap-6">
        <h1 className="text-lg font-semibold text-card-foreground">RCM Analytics Dashboard</h1>
      </div>

      <div className="flex items-center gap-4">
        {/* Date Range Filter */}
        <div className="hidden items-center gap-3 md:flex">
          {/* From Date */}
          <div ref={fromRef} className="relative">
            <button
              onClick={() => {
                setFromOpen(!fromOpen)
                setToOpen(false)
              }}
              className="flex items-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary"
            >
              <span className="text-xs text-muted-foreground">From</span>
              <span>{dateRange.from}</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>

            {fromOpen && (
              <div className="absolute top-full right-0 mt-1 z-50 w-48 rounded-md border border-input bg-background shadow-md">
                <div className="max-h-64 overflow-y-auto">
                  {months.map((month) => (
                    <button
                      key={month}
                      onClick={() => {
                        setDateRange({ ...dateRange, from: month })
                        setFromOpen(false)
                      }}
                      className="flex w-full items-center gap-3 px-4 py-2.5 text-sm hover:bg-secondary"
                    >
                      <span className="text-foreground">{month}</span>
                      {dateRange.from === month && (
                        <svg className="ml-auto h-4 w-4 text-primary" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* To Date */}
          <div ref={toRef} className="relative">
            <button
              onClick={() => {
                setToOpen(!toOpen)
                setFromOpen(false)
              }}
              className="flex items-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary"
            >
              <span className="text-xs text-muted-foreground">To</span>
              <span>{dateRange.to}</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>

            {toOpen && (
              <div className="absolute top-full right-0 mt-1 z-50 w-48 rounded-md border border-input bg-background shadow-md">
                <div className="max-h-64 overflow-y-auto">
                  {months.map((month) => (
                    <button
                      key={month}
                      onClick={() => {
                        setDateRange({ ...dateRange, to: month })
                        setToOpen(false)
                      }}
                      className="flex w-full items-center gap-3 px-4 py-2.5 text-sm hover:bg-secondary"
                    >
                      <span className="text-foreground">{month}</span>
                      {dateRange.to === month && (
                        <svg className="ml-auto h-4 w-4 text-primary" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
          className="relative flex h-8 w-16 items-center rounded-full border border-input bg-background p-1 transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {/* Track icons */}
          <Sun className="absolute left-1.5 h-3.5 w-3.5 text-muted-foreground" />
          <Moon className="absolute right-1.5 h-3.5 w-3.5 text-muted-foreground" />
          {/* Sliding thumb */}
          <span
            className={`relative z-10 flex h-6 w-6 items-center justify-center rounded-full bg-primary shadow-sm transition-transform duration-200 ${
              isDark ? "translate-x-8" : "translate-x-0"
            }`}
          >
            {isDark ? (
              <Moon className="h-3 w-3 text-primary-foreground" />
            ) : (
              <Sun className="h-3 w-3 text-primary-foreground" />
            )}
          </span>
        </button>
      </div>
    </header>
  )
}