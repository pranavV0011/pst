"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"

const BLUE = "hsl(217, 91%, 60%)"

export function KPITrendChart({
  kpiKey,
  monthlyTrend,
  config,
}: {
  kpiKey: string
  monthlyTrend: any[]
  config: any
}) {
  if (!monthlyTrend || monthlyTrend.length === 0) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Monthly Trend</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">
            No data available
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold">Monthly Trend</CardTitle>
      </CardHeader>
      <CardContent className="h-[calc(100%-56px)]">
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={monthlyTrend} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
            <defs>
              <linearGradient id="blueGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={BLUE} stopOpacity={0.2} />
                <stop offset="95%" stopColor={BLUE} stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" style={{ fontSize: "12px" }} />
            <YAxis stroke="hsl(var(--muted-foreground))" style={{ fontSize: "12px" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--background))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px",
              }}
              formatter={(value: number) =>{
                if (kpiKey == "totalPayemnts") {
                  return [
                    `$${value.toLocaleString("en-US")}`,
                    config?.label || "Total Payments",
                  ]
                }

                if (kpiKey == "gcr"){
                  return [
                    `${value.toFixed(2)}%`,
                    config?.label || "GCR",
                  ]
                }

                if (kpiKey == "totalClaims") {
                  return [
                   value.toLocaleString("en-US"),
                  config?.label || "Total Claims"
                  ]
                }

                if (kpiKey == "denialRate") {
                  return [
                    `${value.toFixed(2)}%`,
                    config?.label || "Denial Rate"
                  ]
                }
                
                return [`$${value.toLocaleString("en-US")}`, config?.label || "Value"]
              }}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke={BLUE}
              fill="url(#blueGradient)"
              dot={{ fill: BLUE, r: 4 }}
              activeDot={{ r: 6 }}
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}