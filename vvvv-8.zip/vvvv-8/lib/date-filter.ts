// Parse month string like "Nov 24" to Date object
function parseMonthString(monthStr: string): Date {
  const [month, year] = monthStr.trim().split(/\s+/)
  const fullYear = parseInt(year) > 50 ? `19${year}` : `20${year}`
  return new Date(`${month} 1, ${fullYear}`)
}

// Compare two month strings chronologically
function compareMonths(month1: string, month2: string): number {
  const date1 = parseMonthString(month1)
  const date2 = parseMonthString(month2)
  return date1.getTime() - date2.getTime()
}

// Universal filter that works with any date range, not limited by hardcoded months
export function filterByDateRange(data: any[], dateRange: { from: string; to: string }, monthColumn: string = "month"): any[] {
  const fromDate = parseMonthString(dateRange.from)
  const toDate = parseMonthString(dateRange.to)

  return data.filter((item) => {
    const itemMonth = item[monthColumn]?.toString() || ""
    if (!itemMonth) return false
    
    const itemDate = parseMonthString(itemMonth)
    return itemDate >= fromDate && itemDate <= toDate
  })
}

// Convert numeric month to label (1-12)
export function convertMonthToLabel(month: string): string {
  const monthNum = parseInt(month)
  if (isNaN(monthNum) || monthNum < 1 || monthNum > 12) return month
  
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  const currentYear = new Date().getFullYear()
  const yy = (currentYear % 100).toString().padStart(2, "0")
  
  return `${monthNames[monthNum - 1]} ${yy}`
}

// Get days in a given month in "mmm yy" format
export function getDaysInMonth(mmmYY: string): number {
  const date = parseMonthString(mmmYY)
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate()
}

// Get total days in a date range (works with any dates)
export function getTotalDaysInRange(dateRange: { from: string; to: string }): number {
  const fromDate = parseMonthString(dateRange.from)
  const toDate = parseMonthString(dateRange.to)
  
  let totalDays = 0
  const currentDate = new Date(fromDate)
  
  while (currentDate <= toDate) {
    totalDays += new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate()
    currentDate.setMonth(currentDate.getMonth() + 1)
  }
  
  return totalDays || 1
}

// Calculate previous period for year-over-year comparison (universal for any dates)
export function getPreviousPeriod(dateRange: { from: string; to: string }): { from: string; to: string } {
  const fromDate = parseMonthString(dateRange.from)
  const toDate = parseMonthString(dateRange.to)
  
  // Go back 12 months
  const prevFromDate = new Date(fromDate)
  prevFromDate.setFullYear(prevFromDate.getFullYear() - 1)
  
  const prevToDate = new Date(toDate)
  prevToDate.setFullYear(prevToDate.getFullYear() - 1)
  
  // Format back to "mmm yy"
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  const formatDate = (d: Date) => {
    const month = monthNames[d.getMonth()]
    const year = (d.getFullYear() % 100).toString().padStart(2, "0")
    return `${month} ${year}`
  }
  
  return {
    from: formatDate(prevFromDate),
    to: formatDate(prevToDate),
  }
}
