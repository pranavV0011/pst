/**
 * users.ts
 *
 * Simple hardcoded user store — no hashing.
 * Replace with your real DB when ready.
 */

export interface User {
  id: string
  name: string
  email: string
  password: string
  createdAt: Date
}

const users: User[] = [
  {
    id: "user_demo_001",
    name: "Demo User",
    email: "jorie@example.com",
    password: "jorie123",
    createdAt: new Date(),
  },
]

export function findUserByEmail(email: string): User | undefined {
  return users.find((u) => u.email.toLowerCase() === email.toLowerCase())
}

export function findUserById(id: string): User | undefined {
  return users.find((u) => u.id === id)
}

export function createUser(data: Omit<User, "id" | "createdAt">): User {
  const user: User = {
    ...data,
    id: `user_${crypto.randomUUID()}`,
    createdAt: new Date(),
  }
  users.push(user)
  return user
}