import * as XLSX from 'xlsx';

export interface ClientPerformanceData {
  name: string;
  gcr: number;
  totalPayment: number;
  dr: number;
  status: string;
}

export interface PerformanceMetric {
  month: string;
  GCR: number;
  DR: number;
  CCR: number;
}

export interface ComparisonMetric {
  name: string;
  previous: number;
  current: number;
}

/**
 * Parse Excel file and extract client performance data
 * Expected columns: Client, GCR, Total Payment, DR, Status
 */
export async function parseClientPerformanceExcel(file: File): Promise<ClientPerformanceData[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        const parsed = (jsonData as any[]).map((row) => ({
          name: row['Client'] || row['client'] || '',
          gcr: parseFloat(row['GCR'] || row['gcr'] || 0),
          totalPayment: parseFloat(row['Total Payment'] || row['total payment'] || 0),
          dr: parseFloat(row['DR'] || row['dr'] || 0),
          status: row['Status'] || row['status'] || 'Fair',
        }));
        
        resolve(parsed);
      } catch (error) {
        reject(error);
        
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Parse Excel file and extract performance metrics
 * Expected columns: Month, GCR, DR, CCR
 */
export async function parsePerformanceMetricsExcel(file: File): Promise<PerformanceMetric[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        const parsed = (jsonData as any[]).map((row) => ({
          month: row['Month'] || row['month'] || '',
          GCR: parseFloat(row['GCR'] || row['gcr'] || 0),
          DR: parseFloat(row['DR'] || row['dr'] || 0),
          CCR: parseFloat(row['CCR'] || row['ccr'] || 0),
        }));
        
        resolve(parsed);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsArrayBuffer(file);
  });
}
