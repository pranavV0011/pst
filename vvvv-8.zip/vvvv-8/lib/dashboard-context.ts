"use client"

import { createContext, useContext } from "react"

export type DashboardType = "all-clients" | "abc" | "dce" | "pom" | "southside"

interface DateRange {
  from: string
  to: string
}

interface DashboardContextType {
  activeDashboard: DashboardType
  setActiveDashboard: (dashboard: DashboardType) => void
  dateRange: DateRange
  setDateRange: (range: DateRange) => void
}

export const DashboardContext = createContext<DashboardContextType | undefined>(undefined)

export function useDashboard() {
  const context = useContext(DashboardContext)
  if (!context) {
    throw new Error("useDashboard must be used within DashboardProvider")
  }
  return context
}

