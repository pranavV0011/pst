"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"

interface AuthUser {
  id: string
  name: string
  email: string
}

interface AuthState {
  user: AuthUser | null
  loading: boolean
}

export function useAuth() {
  const [state, setState] = useState<AuthState>({ user: null, loading: true })
  const router = useRouter()

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((data) => setState({ user: data.user ?? null, loading: false }))
      .catch(() => setState({ user: null, loading: false }))
  }, [])

  const logout = useCallback(async () => {
    await fetch("/api/auth/logout", { method: "POST" })
    setState({ user: null, loading: false })
    router.push("/login")
  }, [router])

  return { ...state, logout }
}