import { SignJWT, jwtVerify } from "jose"
import { cookies } from "next/headers"

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET ?? "change-this-secret-in-production"
)

export const COOKIE_NAME = "jorie_session"
export const COOKIE_MAX_AGE = 60 * 60 * 24 * 7 // 7 days

// ─── Token ────────────────────────────────────────────────────────────────────

export async function signToken(payload: { id: string; email: string; name: string }) {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(SECRET)
}

export async function verifyToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, SECRET)
    return payload as { id: string; email: string; name: string }
  } catch {
    return null
  }
}

// ─── Session helpers (Server Components / Route Handlers) ─────────────────────

export async function getSession() {
  const cookieStore = await cookies()
  const token = cookieStore.get(COOKIE_NAME)?.value
  if (!token) return null
  return verifyToken(token)
}

export async function requireSession() {
  const session = await getSession()
  if (!session) return null
  return session
}

// ─── Password (bcrypt-free, Web Crypto) ───────────────────────────────────────

async function deriveKey(password: string, salt: Uint8Array) {
  const enc = new TextEncoder()
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    "PBKDF2",
    false,
    ["deriveBits"]
  )
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 200_000, hash: "SHA-256" },
    keyMaterial,
    256
  )
  return Buffer.from(bits).toString("hex")
}

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16))
  const hash = await deriveKey(password, salt)
  return `${Buffer.from(salt).toString("hex")}:${hash}`
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [saltHex, hash] = stored.split(":")
  const salt = Buffer.from(saltHex, "hex")
  const derived = await deriveKey(password, salt)
  return derived === hash
}