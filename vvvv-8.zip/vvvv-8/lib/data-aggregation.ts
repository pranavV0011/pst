import { loadKPIData, loadAutomationData } from './csv-loader'

export interface DashboardKPI {
  totalClaims: number
  totalPayment: number
  totalBilled: number
  chargePerVisit: number
  gcr: number
  denialRate: number
  ccr: number
  arDays: number
  dailyAvgCharges: number
  arBuckets: {
    '0-30': number
    '31-60': number
    '61-90': number
    '90+': number
  }
  arBucketsPercentage: {
    '0-30': number
    '31-60': number
    '61-90': number
    '90+': number
  }
}

export interface MonthlyTrend {
  month: string
  value: number
}

export interface AutomationKPI {
  name: string
  percentage: number
  value: number
  totalValue: number
}

// Parse month string like "Jan 24" or "January" to extract month and year
export function parseMonthYear(monthStr: string): { month: number; year: number } {
  const monthMap: Record<string, number> = {
    'jan': 1, 'january': 1,
    'feb': 2, 'february': 2,
    'mar': 3, 'march': 3,
    'apr': 4, 'april': 4,
    'may': 5,
    'jun': 6, 'june': 6,
    'jul': 7, 'july': 7,
    'aug': 8, 'august': 8,
    'sep': 9, 'september': 9,
    'oct': 10, 'october': 10,
    'nov': 11, 'november': 11,
    'dec': 12, 'december': 12,
  }

  const parts = monthStr.trim().split(' ')
  const month = monthMap[parts[0].toLowerCase()] || 1
  const year = parts[1] ? parseInt(`20${parts[1]}`) : new Date().getFullYear()

  return { month, year }
}

// Extract month from CSV Month column (format: "Jan 24")
export function extractMonthYear(csvMonth: string): { month: number; year: number } {
  return parseMonthYear(csvMonth)
}

// Filter data for a single month
export function filterDataByMonth(data: Record<string, any>[], targetMonth: string): Record<string, any>[] {
  const { month, year } = parseMonthYear(targetMonth)
  return data.filter(row => {
    const csvMonth = row['Month&Year'] || row['Month'] || row['Month\u200B'] || ''
    if (!csvMonth) return false
    const { month: rowMonth, year: rowYear } = extractMonthYear(csvMonth)
    return rowMonth === month && rowYear === year
  })
}

// Filter data by date range (from and to months)
export function filterDataByDateRange(
  data: Record<string, any>[],
  fromMonth: string,
  toMonth: string
): Record<string, any>[] {
  const { month: fromM, year: fromY } = parseMonthYear(fromMonth)
  const { month: toM, year: toY } = parseMonthYear(toMonth)

  return data.filter(row => {
    const csvMonth = row['Month&Year'] || row['Month​'] || ''
    const { month: rowMonth, year: rowYear } = extractMonthYear(csvMonth)
    const rowDate = rowYear * 12 + rowMonth
    const fromDate = fromY * 12 + fromM
    const toDate = toY * 12 + toM

    return rowDate >= fromDate && rowDate <= toDate
  })
}

// Get previous year period (e.g., if current is Jan 25, previous is Jan 24)
export function getPreviousYearPeriod(month: string): string {
  const { month: m, year: y } = parseMonthYear(month)
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  return `${monthNames[m - 1]} ${String(y - 1).slice(-2)}`
}

// Calculate KPIs for a filtered dataset
export async function calculateKPIs(data: Record<string, any>[]): Promise<DashboardKPI> {
  const totalClaims = data.reduce((sum, row) => sum + (Number(row['Visit']) || 0), 0)
  const totalPayment = data.reduce((sum, row) => sum + (Number(row['Payments']) || 0), 0)
  const totalBilled = data.reduce((sum, row) => sum + (Number(row['Charges']) || 0), 0)

  // Calculate GCR (average)
  const gcrValues = data
    .filter(row => row['GCR'])
    .map(row => Number(row['GCR']))
  const gcr = gcrValues.length > 0 ? gcrValues.reduce((a, b) => a + b) / gcrValues.length : 0

  // Calculate average values
  const denialRates = data
  .map(row => Number(row['Denial Rate']))
  .filter(val => !isNaN(val))

const denialRate =
  denialRates.length > 0
    ? denialRates.reduce((sum, val) => sum + val, 0) / denialRates.length
    : 0

  const ccrValues = data
    .map(row => Number(row['Clean Claim Rate'] ?? row['CCR']))
    .filter(val => !isNaN(val))

  const ccr =
    ccrValues.length > 0
      ? ccrValues.reduce((sum, val) => sum + val, 0) / ccrValues.length
      : 0

  const chargePerVisit = totalClaims > 0 ? totalBilled/totalClaims : 0

  const arDaysValues = data
    .filter(row => row['AR Days'] || row['AR'])
    .map(row => Number(row['AR Days'] || row['AR']))
  const arDays = arDaysValues.length > 0 ? arDaysValues.reduce((a, b) => a + b) / arDaysValues.length : 0

  // Daily average charges = sum of charges / number of days (approx 30 days per month * number of months)
  const numberOfDays = data.length > 0 ? data.length * 30 : 1
  const dailyAvgCharges = (totalBilled / numberOfDays) * 100

  // AR Buckets
const arBuckets = {
    '0-30': data.reduce((sum, row) => sum + (Number(row['0-30']) || 0), 0),
    '31-60': data.reduce((sum, row) => sum + (Number(row['31-60']) || 0), 0),
    '61-90': data.reduce((sum, row) => sum + (Number(row['61-90']) || 0), 0),
    '90+': data.reduce((sum, row) => sum + (Number(row['90+']) || 0), 0),
  }

  const totalAR = Object.values(arBuckets).reduce((a, b) => a + b, 0)
  const arBucketsPercentage = {
    '0-30': totalAR > 0 ? (arBuckets['0-30'] / totalAR) * 100 : 0,
    '31-60': totalAR > 0 ? (arBuckets['31-60'] / totalAR) * 100 : 0,
    '61-90': totalAR > 0 ? (arBuckets['61-90'] / totalAR) * 100 : 0,
    '90+': totalAR > 0 ? (arBuckets['90+'] / totalAR) * 100 : 0,
  }


  return {
    totalClaims,
    totalPayment,
    totalBilled,
    gcr,
    denialRate,
    ccr,
    arDays,
    dailyAvgCharges,
    arBuckets,
    arBucketsPercentage,
    chargePerVisit
    
  }
}

// Get monthly trend data (for charts)
export function getMonthlyTrend(
  data: Record<string, any>[],
  columnName: string,
  operation: 'sum' | 'avg' = 'sum'
): MonthlyTrend[] {
  const monthlyData: Record<string, number[]> = {}

  data.forEach(row => {
    const monthStr = row['Month&Year'] || row['Month​'] || ''
    const value = Number(row[columnName]) || 0

    if (!monthlyData[monthStr]) {
      monthlyData[monthStr] = []
    }
    monthlyData[monthStr].push(value)
  })

  return Object.entries(monthlyData).map(([month, values]) => ({
    month,
    value: operation === 'sum' ? values.reduce((a, b) => a + b, 0) : values.reduce((a, b) => a + b) / values.length,
  }))
}

// Get AR Days and Claims monthly trend (for comparison)
export function getARAndClaimsTrend(data: Record<string, any>[]): { arDays: MonthlyTrend[]; claims: MonthlyTrend[] } {
  const arTrend = getMonthlyTrend(data, 'AR Days', 'avg')
  const claimsTrend = getMonthlyTrend(data, 'Visit', 'sum')

  return { arDays: arTrend, claims: claimsTrend }
}

// Calculate automation KPIs from automation CSV
export async function calculateAutomationKPIs(
  data: Record<string, any>[],
  monthFilter: string
): Promise<AutomationKPI[]> {
  const filteredData = filterDataByMonth(data, monthFilter)

  return filteredData.map(row => {
    const name = row['label'] || row['name'] || ''
    const botPayment = Number(row['BOTPAYMENT'] || row['value'] || 0)
    const totalVolPayment = Number(row['TOTALVOLPAYMENT'] || row['total'] || 100)
    const percentage = totalVolPayment > 0 ? (botPayment / totalVolPayment) * 100 : 0

    return {
      name,
      percentage,
      value: botPayment,
      totalValue: totalVolPayment,
    }
  })
}

export function getChargePerVisitTrend(
  data: Record<string, any>[]
): MonthlyTrend[]{
  const monthlyMap: Record<string, {charges: number; visits: number}> = {}

  data.forEach((row) => {
    const monthStr = row['Month&Year'] || ''
    const charges = Number(row['Charges']) || 0
    const visits = Number(row['Visit']) || 0

    if(!monthlyMap[monthStr]){
      monthlyMap[monthStr] = {charges: 0, visits: 0}
    }

    monthlyMap[monthStr].charges += charges
    monthlyMap[monthStr].visits += visits
  })

  return Object.entries(monthlyMap).map(([month, values]) => ({
    month,
    value:
      values.visits > 0
        ? Number((values.charges / values.visits).toFixed(0))
        : 0,
  }))
}

// Get all available clients from public data folders
export async function getAvailableClients(): Promise<string[]> {
  const clients: string[] = ['all-clients', 'abc', 'dce', 'pom', 'southside']
  // In a real app, you'd check which folders exist in /public/data/
  return clients
}

// Get performance trend data (GCR, DR, CCR)
export function getPerformanceTrend(
  data: Record<string, any>[],
  columnName: string
): MonthlyTrend[] {
  return getMonthlyTrend(data, columnName, 'avg')
}

// Get revenue trend (Payments vs Charges)
export function getRevenueTrend(data: Record<string, any>[]): {
  payments: MonthlyTrend[]
  charges: MonthlyTrend[]
} {
  const payments = getMonthlyTrend(data, 'Payments', 'sum')
  const charges = getMonthlyTrend(data, 'Charges', 'sum')

  return { payments, charges }
}

// Get number of days for a date range
export function getNumberOfDays(fromMonth: string, toMonth: string): number {
  const { month: fromM, year: fromY } = parseMonthYear(fromMonth)
  const { month: toM, year: toY } = parseMonthYear(toMonth)

  const fromDate = new Date(fromY, fromM - 1, 1)
  const toDate = new Date(toY, toM, 0)

  const diffTime = Math.abs(toDate.getTime() - fromDate.getTime())
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1

  return diffDays
}
