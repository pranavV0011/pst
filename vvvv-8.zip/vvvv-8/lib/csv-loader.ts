export async function loadCSV(filename: string, client?: string): Promise<Record<string, any>[]> {
  try {
    const folderPath = client && client !== "all-clients" ? `/data/${client}/` : `/data/`
    const response = await fetch(`${folderPath}${filename}.csv`)
    if (!response.ok) {
      throw new Error(`Failed to load ${folderPath}${filename}.csv`)
    }
    const csvText = await response.text()
    return parseCSV(csvText)
  } catch (error) {
    console.error(`Error loading CSV ${filename}:`, error)
    return []
  }
}

export function parseCSV(csvText: string): Record<string, any>[] {
  const lines = csvText.trim().split('\n')
  if (lines.length === 0) return []

  const headers = lines[0].split(',').map(h => h.trim())
  const rows: Record<string, any>[] = []

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim())
    const row: Record<string, any> = {}

    headers.forEach((header, index) => {
      const value = values[index]
      row[header] = isNaN(Number(value)) ? value : Number(value)
    })

    rows.push(row)
  }

  return rows
}

// Load data from all clients and aggregate
export async function loadAllClientsData(filename: string): Promise<Record<string, any>[]> {
  const clients = ['abc', 'dce', 'pom', 'southside'] // Add more client folders as needed
  let aggregatedData: Record<string, any>[] = []

  for (const client of clients) {
    try {
      const data = await loadCSV(filename, client)
      aggregatedData = aggregatedData.concat(data)
    } catch (error) {
      console.error(`Error loading data for client ${client}:`, error)
    }
  }

  return aggregatedData
}

// Get automation KPI columns (dynamic based on CSV structure)
export function getAutomationKPIColumns(headers: string[]): string[] {
  // Filter columns that are not metadata (exclude 'Month', 'month', etc.)
  return headers.filter(h => {
    const lower = h.toLowerCase()
    return !['month', 'date', 'client', 'year'].includes(lower) && h.trim() !== ''
  })
}

// Calculate percentage for automation KPI
export function calculateAutomationPercentage(row: Record<string, any>, botColumn: string, totalColumn: string): number {
  const bot = Number(row[botColumn]) || 0
  const total = Number(row[totalColumn]) || 0
  if (total === 0) return 0
  return (bot / total) * 100
}

export async function loadAutomationData(client: string = "all-clients"): Promise<Record<string, any>[]> {
  if (client === "all-clients") {
    // For all-clients, aggregate from all client folders
    const allData = await loadAllClientsData('automation')
    // If no client data found, fall back to root automation.csv
    if (allData.length === 0) {
      return loadCSV('automation')
    }
    return allData
  }
  return loadCSV('automation', client)
}

export async function loadKPIData(client: string = "all-clients"): Promise<Record<string, any>[]> {
  if (client === "all-clients") {
    return loadAllClientsData('data')
  }
  return loadCSV('data', client)
}
