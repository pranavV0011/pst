import { NextRequest, NextResponse } from "next/server"
import { verifyToken, COOKIE_NAME } from "@/lib/auth"

// Routes that require a valid session
const PROTECTED = ["/dashboard"]

// Routes only for guests (redirect logged-in users away)
const GUEST_ONLY = ["/login"]

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  const token = req.cookies.get(COOKIE_NAME)?.value
  const session = token ? await verifyToken(token) : null

  const isProtected = PROTECTED.some((p) => pathname.startsWith(p))
  const isGuestOnly = GUEST_ONLY.some((p) => pathname.startsWith(p))

  // Unauthenticated user hitting a protected route → send to /login
  if (isProtected && !session) {
    const url = req.nextUrl.clone()
    url.pathname = "/login"
    url.searchParams.set("from", pathname) // preserve intended destination
    return NextResponse.redirect(url)
  }

  // Authenticated user hitting /login → send to dashboard
  if (isGuestOnly && session) {
    const url = req.nextUrl.clone()
    url.pathname = "/dashboard/all-clients"
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  // Run on all routes except Next.js internals and static assets
  matcher: ["/((?!_next/static|_next/image|favicon.ico|logo.*\\.png).*)"],
}